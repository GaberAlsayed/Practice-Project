A Pen created at CodePen.io. You can find this one at https://codepen.io/GaberAlsayed/pen/ZvpRPR.

 This is a YT tribute project  that I just finished, this project was originally made by CodingTutorials360. I am rewriting the code to get a basic understanding on how to make my own tribute page.